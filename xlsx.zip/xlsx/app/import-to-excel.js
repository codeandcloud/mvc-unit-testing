$(document).ready(function () {
    SFT.Init();
});

var SFT = (function () {

    var init = function () {
        _exportToExcelButtonClickHandler();
    };

    var _exportToExcelButtonClickHandler = function () {
        $("#export-excel").on("click", function (evt) {

            evt.preventDefault();

            setFileName();

            var tableData = getTableData();
            var wbout = writeExcelSheet(tableData);

            exportExcelSheet(wbout);
        });
    };
    var getTableData = function () {
        var data = [];
        var tableElm = $("#item-table");
        tableElm.find("thead tr").each(function(){
            var row = [];
            $(this).find('th').each(function(){
                row.push($(this).text());
            });
            data.push(row);
        });
        tableElm.find("tbody tr").each(function(){
            var row = [];
            $(this).find('td').each(function(){
                row.push($(this).find('label').text());
            });
            data.push(row);
        });
        return data;
    };

    var writeExcelSheet = function (ws_data) {
        var wb = XLSX.utils.book_new();
        wb.Props = {
            Title: "SFT Query",
            Subject: "SFT Query",
            Author: "SFT",
            CreatedDate: new Date()
        };

        wb.SheetNames.push("SFT Query");

        var ws = XLSX.utils.aoa_to_sheet(ws_data);
        wb.Sheets["SFT Query"] = ws;

        return XLSX.write(wb, {
            bookType: 'xlsx',
            type: 'binary'
        });
    };

    var exportExcelSheet = function (wbout) {
        saveAs(
            new Blob(
                [s2ab(wbout)], 
                { type: "application/octet-stream" }
            ), 
            SFT.FileName
        );
    };

    var s2ab = function (s) {

        var buf = new ArrayBuffer(s.length);
        var view = new Uint8Array(buf);
        for (var i = 0; i < s.length; i++) view[i] = s.charCodeAt(i) & 0xFF;
        return buf;

    };

    var addZero = function (i) {
        if (i < 10) {
            i = "0" + i;
        }
        return i;
    };

    var setFileName = function () {
        var today = new Date();
        var nHrs = addZero(today.getHours());
        var nMin = addZero(today.getMinutes());
        var nSec = addZero(today.getSeconds());
        var nDate = addZero(today.getDate());
        var nMnth = addZero(today.getMonth() + 1);
        var nYear = addZero(today.getFullYear());
        var currentDateTime = nDate + '-' +
            nMnth + '-' +
            nYear + ' ' +
            nHrs + '-' +
            nMin + '-' +
            nSec;
        SFT.FileName = 'SFT-Query-' + currentDateTime + '.xlsx';
    };

    return {
        Init: init,
        FileName: ''
    };

})();