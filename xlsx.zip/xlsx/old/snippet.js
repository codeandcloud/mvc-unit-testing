
 
  var _exportToExcelButtonClickHandler = function() {
    $("#export-excel").on("click", function(evt) {
      evt.preventDefault();
      var data_type = 'data:application/vnd.ms-excel';
      var table_div = $(".table-responsive")[0];
      var table_format = table_div.outerHTML.replace("table-bordered\"", "table-bordered\" border='1' cellspacing='0'")
      var table_html = table_format.replace(/ /g, '%20');
      var a = document.createElement('a');
      a.href = data_type + ', ' + table_html;
 
      var oDate = new Date();
      var nHrs = _addZero(oDate.getHours());
      var nMin = _addZero(oDate.getMinutes());
      var nSec = _addZero(oDate.getSeconds());
      var nDate = _addZero(oDate.getDate());
      var nMnth = _addZero(oDate.getMonth() + 1);
      var nYear = _addZero(oDate.getFullYear());
 
      var currentDateTime = nDate + '-' + nMnth + '-' + nYear + ' ' + nHrs + '-' + nMin + '-' + nSec;
      a.download = 'SFT-Query-' + currentDateTime + '.xls';
      a.click();
    });
  };
 